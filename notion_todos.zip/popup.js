document.addEventListener("DOMContentLoaded", () => {
  const languageSelect = document.getElementById("language");
  const saveButton = document.getElementById("save");

  // Load saved language
  chrome.storage.sync.get(["language"], (result) => {
    const currentLang = result.language || "en";
    languageSelect.value = currentLang;
  });

  // Save language
  saveButton.addEventListener("click", () => {
    chrome.storage.sync.set(
      {
        language: languageSelect.value,
        languageUpdatedAt: Date.now(),
      },
      () => {
        // 저장 완료 표시 후 모달 닫기
        saveButton.textContent = "✓";
        setTimeout(() => {
          window.close();
        }, 500);
      }
    );
  });
});
